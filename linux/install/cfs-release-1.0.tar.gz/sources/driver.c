#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <clarasoft/cfs.h>

int main(int argc, char** argv) {

    CFSRPS pRepo;
    CFSCFG pConfig;

    char* pszValue;

    pRepo = CFSRPS_Open(0);

    pConfig = CFSRPS_OpenConfig(pRepo, argv[1]);

    pszValue = CFSCFG_LookupParam(pConfig, "HANDLER");

    printf("Value: %s\n", pszValue);

    return 0;
}

