/* ==========================================================================

  Clarasoft Foundation Server

  generic service handler
  Version 1.0.0

  Distributed under the MIT license

  Copyright (c) 2013 Clarasoft I.T. Solutions Inc.

  Permission is hereby granted, free of charge, to any person obtaining
  a copy of this software and associated documentation files
  (the "Software"), to deal in the Software without restriction,
  including without limitation the rights to use, copy, modify,
  merge, publish, distribute, sub-license, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
  ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH
  THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

========================================================================== */

#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <unistd.h>

#include <clarasoft/cfsapi.h>
#include <clarasoft/cslib.h>

#define BUFF_MAX 129

// Laodable service procedure: we pass the connection 
// and the configuration string

void RunService(CFS_SESSION *pInstance, char *szConfig);

typedef void (*SERVICEPROC)(CFS_SESSION*, char*);


void *inprocServer;

SERVICEPROC pServiceProc;

int conn_fd;
int stream_fd;

CFS_SESSION *pInstance;

void signalCatcher(int signal);

int main(int argc, char **argv)
{

  char buffer = 0; // dummy byte character
                   // to send to main daemon

  int rc;

  struct sigaction sa;

  CSRESULT hResult;

  //CFSRPS repo;
  //CFSRPS_CONFIGINFO cfgi;
  //CFSRPS_PARAMINFO cfgpi;

  sa.sa_handler = signalCatcher;
  sa.sa_flags = 0; // or SA_RESTART
  sigemptyset(&sa.sa_mask);
  sa.sa_sigaction = 0;

  sigaction(SIGTERM, &sa, NULL);
  sigaction(SIGCHLD, &sa, NULL);

  ///////////////////////////////////////////////////////////////////////
  // dynamically load service procedure
  ///////////////////////////////////////////////////////////////////////

  if (argv[2][0] == 'T')
  {
    // This handler is transcient and will end once
    // the connection is ended.

    conn_fd = atoi(argv[1]);
    pInstance = CFS_OpenChannel(0, 0, conn_fd, &rc);

    //pServiceProc(pInstance, argv[3]);
    RunService(pInstance, 0);

    CFS_CloseChannel(pInstance, &rc);
    //dlclose(inprocServer);

    return 0;
  }
  else
  {
    // This handler is resident and will not exit until parent dameon
    // ends.

    pInstance = CFS_OpenChannel(0, 0, 0, &rc);

    stream_fd = atoi(argv[1]);

    /////////////////////////////////////////////////////////////////////
    // Try to send parent a byte; this indicates we are ready
    // to handle a client...
    /////////////////////////////////////////////////////////////////////

    send(stream_fd, &buffer, 1, 0);

    for (;;)
    {
      /////////////////////////////////////////////////////////////////////
      // The main server will eventually hand over the connection socket
      // needed to communicate with a client via the IPC descriptor. 
      /////////////////////////////////////////////////////////////////////

      hResult = CFS_ReceiveDescriptor(stream_fd, &conn_fd, 60);

      if (CS_SUCCEED(hResult))
      {
        CFS_SetChannelDescriptor(pInstance, conn_fd, &rc);

        //pServiceProc(pInstance, argv[3]);
        RunService(pInstance, 0);

        CFS_CloseChannelDescriptor(pInstance, &rc);

        //////////////////////////////////////////////////////////////////
        // Tell main daemon we can handle another connection
        //////////////////////////////////////////////////////////////////

        send(stream_fd, &buffer, 1, 0);
      }
    }
  }

  CFS_CloseChannel(pInstance, &rc);
  close(stream_fd);
  //dlclose(inprocServer);

  return 0;
}

/* --------------------------------------------------------------------------
  signalCatcher
-------------------------------------------------------------------------- */

void signalCatcher(int signal)
{
  int rc;

  switch (signal)
  {
    case SIGTERM:

      CFS_CloseChannel(pInstance, &rc);
      close(stream_fd);
      //dlclose(inprocServer);

      break;
  }

  return;
}

void RunService(CFS_SESSION *pInstance, char *szConfig)
{

  char szMessage[BUFF_MAX];
  char szResponse[BUFF_MAX + 16];

  int rc;

  uint64_t size;

  CSRESULT hResult;

  do
  {
    size = BUFF_MAX;
    hResult = pInstance->lpVtbl->CFS_Read(pInstance,
                                          szMessage,
                                          &size,
                                          -1, &rc);

    if (CS_SUCCEED(hResult))
    {
      // null-terminate message...
      szMessage[size] = 0;

      ////////////////////////////////////////////////////////////
      // Just to give a way for the client to
      // disconnect from this handler, if the first
      // character is the letter q, then we leave
      // the loop.
      ////////////////////////////////////////////////////////////

      if (szMessage[0] == 'q')
      {
        break;
      }

      ////////////////////////////////////////////////////////////
      // echo back the message in a response:
      ////////////////////////////////////////////////////////////

      strcpy(szResponse, "ECHO HANDLER: ");
      strcat(szResponse, szMessage);

      size = strlen(szResponse);

      hResult = pInstance->lpVtbl->CFS_WriteRecord
                                     (pInstance,
                                      szResponse,
                                      &size,
                                      -1, &rc);
    }
  } while (CS_SUCCEED(hResult));

  strcpy(szResponse, "BYE!");

  size = strlen(szResponse);

  hResult = pInstance->lpVtbl->CFS_WriteRecord
                                 (pInstance,
                                  szResponse,
                                  &size,
                                  -1, &rc);

  return;
}


