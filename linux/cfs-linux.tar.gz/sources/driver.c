#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

#include<clarasoft/cslib.h>
#include<clarasoft/cfsapi.h>
#include<clarasoft/cswsck.h>

char*
  CSSTR_StrTok
    (char* szBuffer,
     char* szDelimiter);


int main(int argc, char** argv) {

    char szBuffer[256];
    char szTrim[256];
    char* pTok;
    char* pData;

    CSWSCK pWS;
    int e;
    uint64_t size;

    pWS = CSWSCK_Constructor();

    CSWSCK_OpenSession(pWS, 0, 0, "localhost", "11007", &e);

    strcpy(szBuffer, "CSAP070000000061fc744e-ac76-11ec-b909-0242ac120002TEXT      000000000000000000000Hello");
    strcpy(szBuffer, "{\"op\":\"open\", \"service\":\"CSAP/SERVICE/ECHO\", \"u\":\"\", \"p\":\"\"}");
    size = strlen(szBuffer);
    CSWSCK_Send(pWS,CSWSCK_OPER_TEXT, szBuffer, size, CSWSCK_FIN_ON, -1);
    CSWSCK_Receive(pWS, &size, -1);
    pData = (char*)CSWSCK_GetDataRef(pWS);


    return 0;
}
